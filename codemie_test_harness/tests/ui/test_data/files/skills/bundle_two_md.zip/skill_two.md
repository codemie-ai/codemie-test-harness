---
name: skill-two
description: Second competing skill
---

# Skill Two
