---
name: skill-one
description: First competing skill
---

# Skill One
